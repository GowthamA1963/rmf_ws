# RobotClientAPI.py
#
# ROS-based Robot API used by RobotCommandHandle.
# - Uses /amcl_pose for position
# - Ignores battery topic for now and returns 100% SOC
# - Uses Nav2 NavigateToPose for navigation goals
# - Minimal stubs for process/toggle_action/etc.

import math
import threading
from typing import Dict, Optional

from rclpy.node import Node
from rclpy.action import ActionClient

from geometry_msgs.msg import PoseWithCovarianceStamped
from nav2_msgs.action import NavigateToPose

import threading
import math
class RobotAPI:
    def __init__(self, node: Node):
        # IMPORTANT: reuse the existing fleet node.
        # DO NOT create a new rclpy node here, and DO NOT call rclpy.init() here.
        self._node = node

        # Latest pose
        self._pose_lock = threading.Lock()
        self._pose: Optional[PoseWithCovarianceStamped] = None

        # Per-robot Nav2 action clients and goal results
        self._nav_clients: Dict[str, ActionClient] = {}
        self._goal_results: Dict[str, Dict[int, str]] = {}  # robot_name -> {cmd_id: status}

        # Subscribe only to /amcl_pose for now
        self._node.create_subscription(
            PoseWithCovarianceStamped,
            '/robot2/amcl_pose',          # make sure this matches your actual topic
            self._amcl_cb,
            10
        )

        self._logged_pose_once = False

        self._node.get_logger().info(
            "RobotAPI initialized (ROS-based: /amcl_pose, fixed battery=1.0)"
        )

    # ----------------------------------------------------------------------
    # Subscribers
    # ----------------------------------------------------------------------

    def _amcl_cb(self, msg: PoseWithCovarianceStamped):
        with self._pose_lock:
            self._pose = msg
    
        if not self._logged_pose_once:
            self._logged_pose_once = True
            self._node.get_logger().info(
                f"[RobotAPI] Received first /amcl_pose: "
                f"({msg.pose.pose.position.x:.2f}, {msg.pose.pose.position.y:.2f})"
            )

    # ----------------------------------------------------------------------
    # Position / battery API used by RobotCommandHandle
    # ----------------------------------------------------------------------

    def position(self, robot_name: str):
        """Return [x, y, yaw] in map frame, or None if not available yet."""
        with self._pose_lock:
            if self._pose is None:
                self._node.get_logger().warn(
                    f"[RobotAPI] position() called but /amcl_pose not received yet"
                )
                return None
            
            p = self._pose.pose.pose.position
            q = self._pose.pose.pose.orientation

        # quaternion -> yaw
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        yaw = math.atan2(siny_cosp, cosy_cosp)

        return [p.x, p.y, yaw]

    def battery_soc(self, robot_name: str) -> float:
        """
        Return SOC in [0.0, 1.0].

        We ignore the real battery topic for now because /battery_percentage
        has conflicting message types in your system. To avoid errors and
        let RMF operate, we just report 100% battery.
        """
        return 1.0

    # ----------------------------------------------------------------------
    # Nav2 NavigateToPose integration
    # ----------------------------------------------------------------------

    def _get_nav_client(self, robot_name: str) -> ActionClient:
        if robot_name not in self._nav_clients:
            topic = f'/robot2/navigate_to_pose'
            self._nav_clients[robot_name] = ActionClient(
                self._node, NavigateToPose, topic)
            self._goal_results[robot_name] = {}
            self._node.get_logger().info(
                f"[RobotAPI] Created Nav2 client for [{robot_name}] on [{topic}]"
            )
        return self._nav_clients[robot_name]

    def navigate(self,
                 robot_name: str,
                 cmd_id: int,
                 pose,
                 map_name: str,
                 speed_limit: float = 0.0) -> bool:
        """
        Request robot to navigate to pose [x, y, yaw] in map frame.
        Return True if the request was sent (goal will be accepted or rejected async).
        """
        assert len(pose) >= 3
        x, y, yaw = pose[0], pose[1], pose[2]

        client = self._get_nav_client(robot_name)

        if not client.wait_for_server(timeout_sec=2.0):
            self._node.get_logger().error(
                f"[RobotAPI] Nav2 action server not available for [{robot_name}]"
            )
            return False

        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self._node.get_clock().now().to_msg()
        goal.pose.pose.position.x = x
        goal.pose.pose.position.y = y
        goal.pose.pose.position.z = 0.0

        # yaw -> quaternion (z,w)
        qz = math.sin(yaw / 2.0)
        qw = math.cos(yaw / 2.0)
        goal.pose.pose.orientation.z = qz
        goal.pose.pose.orientation.w = qw

        self._node.get_logger().info(
            f"[RobotAPI] [{robot_name}] Nav2 goal cmd_id={cmd_id} "
            f"({x:.2f}, {y:.2f}, yaw={yaw:.2f}), speed_limit={speed_limit}"
        )

        send_future = client.send_goal_async(goal)

        def goal_response_cb(fut):
            goal_handle = fut.result()
            if not goal_handle.accepted:
                self._node.get_logger().error(
                    f"[RobotAPI] Nav2 goal REJECTED for [{robot_name}], cmd_id={cmd_id}"
                )
                self._goal_results[robot_name][cmd_id] = 'rejected'
                return

            self._node.get_logger().info(
                f"[RobotAPI] Nav2 goal accepted for [{robot_name}], cmd_id={cmd_id}"
            )

            result_future = goal_handle.get_result_async()

            def result_cb(res_fut):
                result = res_fut.result()
                status_code = getattr(result, 'status', None)
                if status_code == 4:  # SUCCEEDED
                    status_str = 'succeeded'
                else:
                    status_str = f'status_{status_code}'
                self._goal_results[robot_name][cmd_id] = status_str
                self._node.get_logger().info(
                    f"[RobotAPI] Nav2 result for [{robot_name}], "
                    f"cmd_id={cmd_id}: {status_str}"
                )

            result_future.add_done_callback(result_cb)

        send_future.add_done_callback(goal_response_cb)
        return True

    def navigation_remaining_duration(self, robot_name: str, cmd_id: int):
        """We don't estimate remaining duration → return None."""
        return None

    def navigation_completed(self, robot_name: str, cmd_id: int) -> bool:
        """
        Return True if Nav2 reported success for this cmd_id.
        RobotCommandHandle polls this.
        """
        robot_results = self._goal_results.get(robot_name, {})
        status = robot_results.get(cmd_id)
        return status == 'succeeded'

    # ----------------------------------------------------------------------
    # Replan / process / toggle stubs
    # ----------------------------------------------------------------------

    def requires_replan(self, robot_name: str) -> bool:
        return False

    def start_process(self,
                      robot_name: str,
                      cmd_id: int,
                      process: str,
                      map_name: str) -> bool:
        self._node.get_logger().info(
            f"[RobotAPI] start_process '{process}' for [{robot_name}], "
            f"cmd_id={cmd_id} (stubbed as immediate success)"
        )
        return True

    def process_completed(self, robot_name: str, cmd_id: int) -> bool:
        return True

    def toggle_action(self, robot_name: str, toggle: bool) -> bool:
        self._node.get_logger().info(
            f"[RobotAPI] toggle_action={toggle} for [{robot_name}] (stub)"
        )
        return True

    def stop(self, robot_name: str, cmd_id: int) -> bool:
        self._node.get_logger().info(
            f"[RobotAPI] stop() requested for [{robot_name}], cmd_id={cmd_id} (stub)"
        )
        return True
